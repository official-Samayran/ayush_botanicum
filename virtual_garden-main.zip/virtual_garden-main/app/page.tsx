import { HomePage } from "@/components/home-page"

export default function Page() {
  return <HomePage />
}